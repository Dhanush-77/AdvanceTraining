
public class TestRectangle extends rectangle {
	
		public static void main(String args[]) {
	        rectangle obj1 = new rectangle();
	        obj1.input();
	        obj1.calculate();
	        obj1.display();
	        System.out.println("****************************");
	        rectangle obj2 = new rectangle();
	        obj2.input();
	        obj2.calculate();
	        obj2.display();
	        System.out.println("****************************");
	        rectangle obj3 = new rectangle();
	        obj3.input();
	        obj3.calculate();
	        obj3.display();
	        System.out.println("****************************");
	        rectangle obj4 = new rectangle();
	        obj4.input();
	        obj4.calculate();
	        obj4.display();
	        System.out.println("****************************");
	        rectangle obj5 = new rectangle();
	        obj5.input();
	        obj5.calculate();
	        obj5.display();
	    }
	}

